package com.example.filter_listview_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
