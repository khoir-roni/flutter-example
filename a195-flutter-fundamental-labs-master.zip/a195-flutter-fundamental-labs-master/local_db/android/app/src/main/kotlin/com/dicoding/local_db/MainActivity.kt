package com.dicoding.local_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
