package com.dicoding.learning_paths

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
