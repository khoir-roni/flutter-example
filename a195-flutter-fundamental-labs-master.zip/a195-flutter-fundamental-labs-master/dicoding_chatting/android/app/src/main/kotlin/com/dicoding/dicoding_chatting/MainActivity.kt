package com.dicoding.dicoding_chatting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
