package com.dicoding.dicodingacademy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
