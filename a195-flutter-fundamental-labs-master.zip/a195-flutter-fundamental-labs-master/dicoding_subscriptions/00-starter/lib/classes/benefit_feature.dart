class BenefitFeature {
  final String feature;
  final bool freeBenefit;
  final bool paidBenefit;
  BenefitFeature(
    this.feature,
    this.freeBenefit,
    this.paidBenefit,
  );
}
