package com.dicoding.flutter_mode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
