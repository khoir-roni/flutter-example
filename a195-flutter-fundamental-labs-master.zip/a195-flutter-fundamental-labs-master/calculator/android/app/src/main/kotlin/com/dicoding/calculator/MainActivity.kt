package com.dicoding.calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
