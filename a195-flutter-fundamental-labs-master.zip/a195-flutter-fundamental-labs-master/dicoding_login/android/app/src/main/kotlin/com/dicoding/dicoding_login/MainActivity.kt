package com.dicoding.dicoding_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
